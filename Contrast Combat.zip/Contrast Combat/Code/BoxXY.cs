using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxXY : MonoBehaviour
{
    KeyCode up, left, down, right, speed, jump;
    [SerializeField]private float speedcoeff;
    // Start is called before the first frame update
    void Start()
    {
        up = KeyCode.W;
        left = KeyCode.A;
        right = KeyCode.D;
        down = KeyCode.S;
        speed = KeyCode.LeftShift;
        jump = KeyCode.Space;

        speedcoeff = 0;
    }

    // Update is called once per frame
    void Update()
    {   
        if(Input.GetKey(speed))
        {
            speedcoeff +=1 * Time.deltaTime;
        }
        if (Input.GetKey(up))
        {
            transform.position += new Vector3(0, 0, speedcoeff * Time.deltaTime);
        }else if (Input.GetKey(right))
        {
            transform.position += new Vector3(speedcoeff * Time.deltaTime, 0, 0);
        }   else if(Input.GetKey(left))
        {
            transform.position -= new Vector3(speedcoeff * Time.deltaTime, 0, 0);
        }   else if(Input.GetKey(down))
        {
            transform.position -= new Vector3(0, 0, speedcoeff * Time.deltaTime);
        }   else if(Input.GetKeyDown(jump))
        {
            GetComponent<Rigidbody>().AddForce(transform.up * 400);

        }
    }
}
